#include <stdio.h>
#include <conio.h>

main ()
{
     float p1, p2, t, media;
     int faltas;
     char msg_nota_aprovado = "Aluno aprovado por nota";
     char msg_nota_reprovado = "Aluno reprovado por nota";
     char msg_faltas_aprovado = "Aluno sem problemas com faltas";
     char msg_faltas_reprovado = "Aluno reprovado por faltas";

     
     /*clrscr();*/
     printf("ola mundo");
     getch();
}
