<?php

/*
This is COMMERSIAL SCRIPT
We are do not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
If you want to have customization, please contact by email - info@wpdevelop.com
*/

if (!class_exists('wpdev_bk_paypal')) {
    class wpdev_bk_paypal {

        // Constructor
        function wpdev_bk_paypal() {

            add_filter('wpdev_booking_form', array(&$this, 'add_paypal_form'));                     // Filter for inserting paypal form
            add_action('wpdev_new_booking', array(&$this, 'show_paypal_form_in_ajax_request'),1,4); // Make showing Paypal in Ajax

            add_action('wpdev_bk_general_settings_end', array(&$this, 'show_general_settings'));    // Write General Settings

            add_action('wpdev_bk_js_define_variables', array(&$this, 'js_define_variables') );      // Write JS variables
            add_action('wpdev_bk_js_write_files', array(&$this, 'js_write_files') );                // Write JS files

            add_filter('wpdev_booking_form' , array(&$this, 'wpdev_booking_form'),10,2 );
            add_filter('wpdev_booking_calendar' , array(&$this, 'wpdev_booking_form'),10,2 );
            
            add_filter('wpdev_booking_form_content', array(&$this, 'wpdev_booking_form_content'),10,2 );
        }

     //   S U P P O R T     F U N C T I O N S    //////////////////////////////////////////////////////////////////////////////////////////////////

        // Get booking types from DB
        function get_booking_type($booking_id) {
            global $wpdb;
            $types_list = $wpdb->get_results( "SELECT title, cost FROM ".$wpdb->prefix ."bookingtypes  WHERE booking_type_id = " . $booking_id );
            return $types_list;
        }

        // Get booking types from DB
        function get_booking_types() {
            global $wpdb;
            $types_list = $wpdb->get_results( "SELECT booking_type_id as id, title, cost FROM ".$wpdb->prefix ."bookingtypes  ORDER BY title" );
            return $types_list;
        }


        // Check if table exist
        function is_field_in_table_exists( $tablename , $fieldname) {
            global $wpdb;
            if (strpos($tablename, $wpdb->prefix) ===false) $tablename = $wpdb->prefix . $tablename ;
            $sql_check_table = "SHOW COLUMNS FROM " . $tablename ;

            $res = $wpdb->get_results($sql_check_table);

            foreach ($res as $fld) {
                if ($fld->Field == $fieldname) return 1;
            }

            return 0;

        }


     //   C L I E N T     S I D E    //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // Define JavaScript variables
        function js_define_variables(){
            ?>
                    <script  type="text/javascript">
                        var days_select_count= <?php echo get_option( 'booking_range_selection_days_count'); ?>;
                        var range_start_day= <?php echo get_option( 'booking_range_start_day'); ?>;
                        <?php if ( get_option( 'booking_range_selection_is_active') == 'On' ) { ?>
                            var is_select_range = 1;
                        <?php } else { ?>
                            var is_select_range = 0;
                        <?php }  ?>
                    </script>
            <?php
        }

        // Write JS files
        function js_write_files(){
            ?> <script type="text/javascript" src="<?php echo WPDEV_BK_PLUGIN_URL; ?>/include/js/wpdev.bk.deluxe.js"></script>  <?php
        }

        // Add Paypal place for inserting to the Booking FORM
        function add_paypal_form($form_content) {

            $paypal_is_active            =  get_option( 'booking_paypal_is_active' );
            if ($paypal_is_active == 'Off') return $form_content ;
            if (strpos($_SERVER['REQUEST_URI'],'booking.php')!==false) return $form_content ;

            $str_start = strpos($form_content, 'booking_form');
            $str_fin = strpos($form_content, '"', $str_start);

            $my_boook_type = substr($form_content,$str_start, ($str_fin-$str_start) );

            $form_content .= '<div  id="paypal'.$my_boook_type.'"></div>';
            return $form_content;
        }

        // Show Paypal form from Ajax request
        function show_paypal_form_in_ajax_request($booking_id, $booking_type, $booking_days_count, $times_array ){

                    $paypal_is_active            =  get_option( 'booking_paypal_is_active' );
                    if ($paypal_is_active == 'Off') return 0 ;

                    $days_array = explode(',', $booking_days_count);
                    $days_count = count($days_array);

                    $paypal_emeil               =  get_option( 'booking_paypal_emeil' );
                    $paypal_curency             =  get_option( 'booking_paypal_curency' );
                    $paypal_subject             =  get_option( 'booking_paypal_subject' );
                    $paypal_is_reference_box    =  get_option( 'booking_paypal_is_reference_box' );           // checkbox
                    $paypal_reference_title_box =  get_option( 'booking_paypal_reference_title_box' );
                    $paypal_return_url          =  get_option( 'booking_paypal_return_url' );
                    $paypal_button_type         =  get_option( 'booking_paypal_button_type' );  // radio
                    $paypal_price_period        =  get_option( 'booking_paypal_price_period' );
                    $bk_title = $this->get_booking_type($booking_type);

                    $paypal_subject = str_replace('[bookingname]',$bk_title[0]->title,$paypal_subject);
                    $paypal_subject = str_replace('[dates]',$booking_days_count,$paypal_subject);

                    //$paypal_subject .= ' Booking type: ' . $bk_title[0]->title . '. For period: ' . $booking_days_count;


                    $output .= '<form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\" style="text-align:left;"> <input type=\"hidden\" name=\"cmd\" value=\"_xclick\" /> ';
                    $output .= "<input type=\"hidden\" name=\"business\" value=\"$paypal_emeil\" />";
                    $output .= "<input type=\"hidden\" name=\"item_name\" value=\"$paypal_subject\" />";
                    $output .= "<input type=\"hidden\" name=\"currency_code\" value=\"$paypal_curency\" />";
                    //$output .= "<span style=\"font-size:10.0pt\"><strong> $paypal_subject</strong></span><br /><br />";

                    $paypal_dayprice = $bk_title[0]->cost;

                    if ($paypal_price_period == 'day') {
                        $output .= "<strong>".__('Cost', 'wpdev-booking')." : ". (1* $paypal_dayprice * $days_count ) ." " . $paypal_curency ."</strong><br/>";
                        $output .= '<input type=\"hidden\" name=\"amount\" size=\"10\" title=\"Cost\" value=\"'. (1* $paypal_dayprice * $days_count ) .'\" />';
                    } elseif ($paypal_price_period == 'night') {
                        if ($days_count>1) $days_count--;
                        $output .= "<strong>".__('Cost', 'wpdev-booking')." : ". (1* $paypal_dayprice * $days_count ) ." " . $paypal_curency ."</strong><br/>";
                        $output .= '<input type=\"hidden\" name=\"amount\" size=\"10\" title=\"Cost\" value=\"'. (1* $paypal_dayprice * $days_count ) .'\" />';
                    } elseif ($paypal_price_period == 'hour') {
                        $start_time = $times_array[0];
                        $end_time   = $times_array[1];

                        if ($days_count == 1 ) {                                      // Selected only 1 day so need to calculate diference in time
                            
                            $m_dif =  ($end_time[0] * 60 + intval($end_time[1]) ) - ($start_time[0] * 60 + intval($start_time[1]) ) ;
                            $h_dif = intval($m_dif / 60) ;
                            $m_dif = ($m_dif - ($h_dif*60) ) / 60 ;

                            $paypal_dayprice = round( ( 1 * $h_dif * $paypal_dayprice ) + ( 1 * $m_dif * $paypal_dayprice ) , 2);
                        } else {                                                    // Selected several days so need to calculate full days price and then some parts of start end end day
                            $full_day_count = $days_count - 2;
                            $full_days_cost = ($full_day_count * 24 * $paypal_dayprice);                                        // Full day price
                            $end_cost = round( ( $end_time[0] * 1 +  ( intval($end_time[1]) / 60 ) ) * $paypal_dayprice, 2) ;   // End day cost
                            $m_dif =  (24 * 60 ) - ($start_time[0] * 60 + intval($start_time[1]) ) ;
                            $h_dif = intval($m_dif / 60) ;
                            $m_dif = ($m_dif - ($h_dif*60) ) / 60 ;
                            $start_cost =  round( ( 1 * $h_dif * $paypal_dayprice ) + ( 1 * $m_dif * $paypal_dayprice ) , 2);   // Start daycost
                            $paypal_dayprice = $start_cost + $full_days_cost + $end_cost;
                        }

                        $output .= "<strong>".__('Cost', 'wpdev-booking')." : ". (1* $paypal_dayprice  ) ." " . $paypal_curency ."</strong><br/>";
                        $output .= '<input type=\"hidden\" name=\"amount\" size=\"10\" title=\"Cost\" value=\"'. (1* $paypal_dayprice ) .'\" />';
                    } else {
                        $output .= "<strong>".__('Cost', 'wpdev-booking')." : ". (1* $paypal_dayprice  ) ." " . $paypal_curency ."</strong><br/>";
                        $output .= '<input type=\"hidden\" name=\"amount\" size=\"10\" title=\"Cost\" value=\"'. (1* $paypal_dayprice  ) .'\" />';
                    }
                    // Show the reference text box
                    if ($paypal_is_reference_box == 'On') {
                        $output .= "<br/><strong> $paypal_reference_title_box :</strong>";
                        $output .= '<input type=\"hidden\" name=\"on0\" value=\"Reference\" />';
                        $output .= '<input type=\"text\" name=\"os0\" maxlength=\"60\" /><br/><br/>';
                    }

                    $output .= '<input type=\"hidden\" name=\"no_shipping\" value=\"2\" /> <input type=\"hidden\" name=\"no_note\" value=\"1\" /> <input type=\"hidden\" name=\"mrb\" value=\"3FWGC6LFTMTUG\" /> <input type=\"hidden\" name=\"bn\" value=\"IC_Sample\" /> ';
                    if (!empty($paypal_return_url))  {   $output .= '<input type=\"hidden\" name=\"return\" value=\"'.$paypal_return_url.'\" />'; }
                    else    {                           $output .='<input type=\"hidden\" name=\"return\" value=\"'. get_bloginfo('home') .'\" />'; }

                    $output .= "<input type=\"image\" src=\"$paypal_button_type\" name=\"submit\" style=\"border:none;\" alt=\"".__('Make payments with payPal - its fast, free and secure!', 'wpdev-booking')."\" />";
                    $output .= '</form>';

                    $output = str_replace("'",'"',$output);
          ?>
                    <script type="text/javascript">
                       document.getElementById('submiting<?php echo $booking_type; ?>').innerHTML ='';
                       document.getElementById('paypalbooking_form<?php echo $booking_type; ?>').innerHTML = '<div class=\"\" style=\"height:200px;margin:20px 0px;\" ><?php echo $output; ?></div>';
                    </script>
          <?php
        }

        // Filter for showing booking form
        function wpdev_booking_form($my_form, $bk_type){

            $my_form .= '<div class="tooltips" id="demotip'.$bk_type.'">&nbsp;'. $bk_type .' </div> ';
            return $my_form;
        }

        function wpdev_booking_form_content ($my_form_content, $bk_type){
            if( get_option( 'booking_range_selection_time_is_active') == 'On' )  {
                if ( strpos($my_form_content, 'name="starttime') !== false )  $my_form_content = str_replace( 'name="starttime', 'name="advanced_stime', $my_form_content);
                if ( strpos($my_form_content, 'name="endtime') !== false )  $my_form_content = str_replace( 'name="endtime', 'name="advanced_etime', $my_form_content);

                $my_form_content .= '<input name="starttime'.$bk_type.'"  id="starttime'.$bk_type.'" type="text" value="'.get_option( 'booking_range_selection_start_time').'" style="display:none;">';
                $my_form_content .= '<input name="endtime'.$bk_type.'"  id="endtime'.$bk_type.'" type="text" value="'.get_option( 'booking_range_selection_end_time').'"  style="display:none;">';
            }
            return $my_form_content;
        }
     //   A D M I N     S I D E    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
        //Show settings page depends from selecting TAB
        function check_settings(){
                ?>
                <?php if ($_GET['tab'] == 'paypal') { $slct_a = 'selected'; } else {$slct_a = '';} ?>
                 | <a href="admin.php?page=<?php echo WPDEV_BK_PLUGIN_DIRNAME . '/'. WPDEV_BK_PLUGIN_FILENAME ; ?>wpdev-booking-option&tab=paypal" class="bk_top_menu <?php echo $slct_a; ?>"><?php _e('Paypal and cost customization', 'wpdev-booking'); ?></a>
                 <div style="height:10px;clear:both;border-bottom:1px solid #cccccc;"></div>
                <?php
                    switch ($_GET['tab']) {

                       case 'paypal':
                        $this->show_settings_content();
                        return false;
                        break;

                     default:
                        return true;
                        break;
                    }


            }


        // Show Settings page booking cost window
        function show_booking_types_cost(){
            if ( isset( $_POST['submit_costs'] ) ) {
                $bk_types = $this->get_booking_types();
                global $wpdb;
                foreach ($bk_types as $bt) {
                    if ( false === $wpdb->query( "UPDATE ".$wpdb->prefix ."bookingtypes SET cost = '".$_POST['type_price'.$bt->id]."' WHERE booking_type_id = " .  $bt->id) ) {
                           echo __('Error during updating to DB booking costs', 'wpdev-booking');  
                    }
                }
                update_option( 'booking_paypal_price_period' , $_POST['paypal_price_period'] );

            } ?>

                      <div class='meta-box'>  <div  class="postbox" > <h3 class='hndle'><span><?php _e('Cost of each booking type', 'wpdev-booking'); ?></span></h3> <div class="inside">

                            <form  name="post_option_cost" action="" method="post" id="post_option_cost" >

                                <?php
                                    $bk_types = $this->get_booking_types();
                                    foreach ($bk_types as $bt) { ?>
                                        <div style="float:left; border:0px solid grey; margin:0px; padding:10px">
                                            <strong><?php echo $bt->title; ?> </strong>:
                                            <input  style="width:70px;" maxlength="7" type="text" value="<?php echo $bt->cost; ?>" name="type_price<?php echo $bt->id; ?>" id="type_price<?php echo $bt->id; ?>">
                                        </div>
                                    <?php
                                    }
                                ?>
                                <div class="clear" style="height:10px;"></div>
                                 <span class="description"><?php 
                                    _e('Please, enter cost', 'wpdev-booking');
                                    ?>
                                     <select id="paypal_price_period" name="paypal_price_period">
                                         <option <?php if( get_option( 'booking_paypal_price_period' ) == 'day') echo "selected"; ?> value="day"><?php _e('for 1 day', 'wpdev-booking'); ?></option>
                                         <option <?php if( get_option( 'booking_paypal_price_period' ) == 'night') echo "selected"; ?> value="night"><?php _e('for 1 night', 'wpdev-booking'); ?></option>
                                         <option <?php if( get_option( 'booking_paypal_price_period' ) == 'fixed') echo "selected"; ?> value="fixed"><?php _e('fixed deposit', 'wpdev-booking'); ?></option>
                                         <?php if ( class_exists('wpdev_bk_time')) { ?>
                                         <option <?php if( get_option( 'booking_paypal_price_period' ) == 'hour') echo "selected"; ?> value="hour"><?php _e('for 1 hour', 'wpdev-booking'); ?></option>
                                         <?php } ?>
                                     </select>
                                    <?php 
                                    _e('of each booking resources. Enter only digits.', 'wpdev-booking');
                                 ?></span>
                                 <div class="clear" style="height:10px;"></div>
                                <input class="button-primary" style="float:right;" type="submit" value="<?php _e('Save costs', 'wpdev-booking'); ?>" name="submit_costs"/>
                                <div class="clear" style="height:10px;"></div>

                            </form>

                       </div> </div> </div>

            <?php
        }


        //Show Settings page
        function show_settings_content() {

            // debuge($_SERVER['HTTP_HOST']);

            if ( isset( $_POST['paypal_emeil'] ) ) {
                     if ( ($_SERVER['HTTP_HOST'] == 'onlinebookingcalendar.com') || ($_SERVER['HTTP_HOST'] == 'www.onlinebookingcalendar.com') ) $_POST['paypal_emeil'] = 'booking@wpdevelop.com';
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     $paypal_emeil =  ($_POST['paypal_emeil']);
                     if ( get_option( 'booking_paypal_emeil' ) !== false  )   update_option( 'booking_paypal_emeil' , $paypal_emeil );
                     else                                                     add_option('booking_paypal_emeil' , $paypal_emeil );
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     $paypal_curency =  ($_POST['paypal_curency']);
                     if ( get_option( 'booking_paypal_curency' ) !== false  )   update_option( 'booking_paypal_curency' , $paypal_curency );
                     else                                                     add_option('booking_paypal_curency' , $paypal_curency );
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     $paypal_subject =  ($_POST['paypal_subject']);
                     if ( get_option( 'booking_paypal_subject' ) !== false  )   update_option( 'booking_paypal_subject' , $paypal_subject );
                     else                                                     add_option('booking_paypal_subject' , $paypal_subject );
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     if (isset( $_POST['paypal_is_active'] ))     $paypal_is_active = 'On';
                     else                                         $paypal_is_active = 'Off';
                     if ( get_option( 'booking_paypal_is_active' ) !== false  )   update_option( 'booking_paypal_is_active' , $paypal_is_active );
                     else                                                     add_option('booking_paypal_is_active' , $paypal_is_active );
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     if (isset( $_POST['paypal_is_reference_box'] ))     $paypal_is_reference_box = 'On';
                     else                                                $paypal_is_reference_box = 'Off';
                     if ( get_option( 'booking_paypal_is_reference_box' ) !== false  )   update_option( 'booking_paypal_is_reference_box' , $paypal_is_reference_box );
                     else                                                     add_option('booking_paypal_is_reference_box' , $paypal_is_reference_box );
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     $paypal_reference_title_box =  ($_POST['paypal_reference_title_box']);
                     if ( get_option( 'booking_paypal_reference_title_box' ) !== false  )   update_option( 'booking_paypal_reference_title_box' , $paypal_reference_title_box );
                     else                                                     add_option('booking_paypal_reference_title_box' , $paypal_reference_title_box );
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     $paypal_return_url =  ($_POST['paypal_return_url']);
                     if ( get_option( 'booking_paypal_return_url' ) !== false  )   update_option( 'booking_paypal_return_url' , $paypal_return_url );
                     else                                                     add_option('booking_paypal_return_url' , $paypal_return_url );
                     ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                     $paypal_button_type =  ($_POST['paypal_button_type']);
                     if ( get_option( 'booking_paypal_button_type' ) !== false  )   update_option( 'booking_paypal_button_type' , $paypal_button_type );
                     else                                                     add_option('booking_paypal_button_type' , $paypal_button_type );


            }
            $paypal_emeil               =  get_option( 'booking_paypal_emeil' );
            $paypal_curency             =  get_option( 'booking_paypal_curency' );
            $paypal_subject             =  get_option( 'booking_paypal_subject' );
            $paypal_is_active           =  get_option( 'booking_paypal_is_active' );
            $paypal_is_reference_box    =  get_option( 'booking_paypal_is_reference_box' );           // checkbox
            $paypal_reference_title_box =  get_option( 'booking_paypal_reference_title_box' );
            $paypal_return_url          =  get_option( 'booking_paypal_return_url' );
            $paypal_button_type         =  get_option( 'booking_paypal_button_type' );  // radio


            ?>

                        <div class="clear" style="height:20px;"></div>
                        <div id="ajax_working"></div>
                        <div id="poststuff" class="metabox-holder">

                        <?php $this->show_booking_types_cost();    ?>

                        <div class='meta-box'>  <div  class="postbox" > <h3 class='hndle'><span><?php _e('PayPal customization', 'wpdev-booking'); ?></span></h3> <div class="inside">

                            <form  name="post_option" action="" method="post" id="post_option" >

                                <table class="form-table settings-table">
                                    <tbody>

                                        <tr valign="top">
                                            <th scope="row">
                                                <label for="paypal_is_active" ><?php _e('PayPal active', 'wpdev-booking'); ?>:</label>
                                            </th>
                                            <td>
                                                <input <?php if ($paypal_is_active == 'On') echo "checked";/**/ ?>  value="<?php echo $paypal_is_active; ?>" name="paypal_is_active" id="paypal_is_active" type="checkbox" />
                                                <span class="description"><?php _e(' Tick this checkbox for using PayPal payment.', 'wpdev-booking');?></span>
                                            </td>
                                        </tr>


                                        <tr valign="top">
                                          <th scope="row">
                                            <label for="paypal_emeil" ><?php _e('Paypal Email address to receive payments', 'wpdev-booking'); ?>:</label>
                                            <br/><?php //printf(__('%syour emeil%s adress'),'<span style="color:#888;font-weight:bold;">','</span>'); ?>
                                          </th>
                                          <td>
                                              <input value="<?php echo $paypal_emeil; ?>" name="paypal_emeil" id="paypal_emeil" class="regular-text code" type="text" size="45" />
                                              <span class="description"><?php printf(__('This is the Paypal Email address where the payments will go', 'wpdev-booking'),'<b>','</b>');?></span>
                                              <?php  if ( ($_SERVER['HTTP_HOST'] == 'onlinebookingcalendar.com') || ($_SERVER['HTTP_HOST'] == 'www.onlinebookingcalendar.com') ) { ?> <span class="description">You do not allow to change emeil because right now you test DEMO</span> <?php } ?>
                                          </td>
                                        </tr>

                                        <tr valign="top">
                                          <th scope="row">
                                            <label for="paypal_curency" ><?php _e('Choose Payment Currency', 'wpdev-booking'); ?>:</label>
                                          </th>
                                          <td>
                                             <select id="paypal_curency" name="paypal_curency">
                                                <option <?php if($paypal_curency == 'USD') echo "selected"; ?> value="USD"><?php _e('U.S. Dollars', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'EUR') echo "selected"; ?> value="EUR"><?php _e('Euros', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'GBP') echo "selected"; ?> value="GBP"><?php _e('Pounds Sterling', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'JPY') echo "selected"; ?> value="JPY"><?php _e('Yen', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'AUD') echo "selected"; ?> value="AUD"><?php _e('Australian Dollars', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'CAD') echo "selected"; ?> value="CAD"><?php _e('Canadian Dollars', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'NZD') echo "selected"; ?> value="NZD"><?php _e('New Zealand Dollar', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'CHF') echo "selected"; ?> value="CHF"><?php _e('Swiss Franc', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'HKD') echo "selected"; ?> value="HKD"><?php _e('Hong Kong Dollar', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'SGD') echo "selected"; ?> value="SGD"><?php _e('Singapore Dollar', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'SEK') echo "selected"; ?> value="SEK"><?php _e('Swedish Krona', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'DKK') echo "selected"; ?> value="DKK"><?php _e('Danish Krone', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'PLN') echo "selected"; ?> value="PLN"><?php _e('Polish Zloty', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'NOK') echo "selected"; ?> value="NOK"><?php _e('Norwegian Krone', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'HUF') echo "selected"; ?> value="HUF"><?php _e('Hungarian Forint', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'CZK') echo "selected"; ?> value="CZK"><?php _e('Czech Koruna', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'ILS') echo "selected"; ?> value="ILS"><?php _e('Israeli Shekel', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'MXN') echo "selected"; ?> value="MXN"><?php _e('Mexican Peso', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'BRL') echo "selected"; ?> value="BRL"><?php _e('Brazilian Real (only for Brazilian users)', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'MYR') echo "selected"; ?> value="MYR"><?php _e('Malaysian Ringgits (only for Malaysian users)', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'PHP') echo "selected"; ?> value="PHP"><?php _e('Philippine Pesos', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'TWD') echo "selected"; ?> value="TWD"><?php _e('Taiwan New Dollars', 'wpdev-booking'); ?></option>
                                                <option <?php if($paypal_curency == 'THB') echo "selected"; ?> value="THB"><?php _e('Thai Baht', 'wpdev-booking'); ?></option>
                                             </select>
                                             <span class="description"><?php printf(__('This is the currency for your visitors to make Payments', 'wpdev-booking'),'<b>','</b>');?></span>
                                          </td>
                                        </tr>

                                      

                                        <tr valign="top">
                                          <th scope="row" >
                                            <label for="paypal_subject" ><?php _e('Payment description', 'wpdev-booking'); ?>:</label><br/><br/>
                                            <span class="description"><?php printf(__('Enter the service name or the reason for the payment here.', 'wpdev-booking'),'<br/>','</b>');?></span>
                                          </th>
                                          <td>


                                    <div style="float:left;margin:10px 0px;width:100%;">
                                    <input id="paypal_subject" name="paypal_subject" class="darker-border"  type="text" maxlength="50" size="59" value="<?php echo $paypal_subject; ?>" />
                                    
                                    </div>
                                    <div style="float:left;margin:10px 0px;width:375px;" class="code_description">
                                        <div style="border:1px solid #cccccc;margin-bottom:10px;padding:3px 0px;">
                                          <span class="description">&nbsp;<?php printf(__(' Use these shortcodes for customization: ', 'wpdev-booking'));?></span><br/><br/>
                                          <span class="description"><?php printf(__('%s[bookingname]%s - inserting name of booking resource, ', 'wpdev-booking'),'<code>','</code>');?></span><br/>
                                          <span class="description"><?php printf(__('%s[dates]%s - inserting list of reserved dates ', 'wpdev-booking'),'<code>','</code>');?></span><br/>
                                        </div>
                                    </div>
                                              <div class="clear"></div>

                                              
                                          </td>
                                        </tr>



                                        <tr valign="top">
                                            <th scope="row">
                                                <label for="paypal_is_reference_box" ><?php _e('Show Reference Text Box', 'wpdev-booking'); ?>:</label>
                                            </th>
                                            <td>
                                                <input <?php if ($paypal_is_reference_box == 'On') echo "checked";/**/ ?>  value="<?php echo $paypal_is_reference_box; ?>" name="paypal_is_reference_box" id="paypal_is_reference_box" type="checkbox"
                                                                                                                           onMouseDown="javascript: document.getElementById('paypal_reference_title_box').disabled=this.checked; "/>
                                                <span class="description"><?php _e(' Tick this checkbox if you want your visitors be able to enter a reference like email or web address.', 'wpdev-booking');?></span>
                                            </td>
                                        </tr>

                                        <tr valign="top">
                                          <th scope="row">
                                            <label for="paypal_reference_title_box" ><?php _e('Reference Text Box Title', 'wpdev-booking'); ?>:</label>
                                          </th>
                                          <td>
                                              <input <?php if ($paypal_is_reference_box !== 'On') echo " disabled "; ?>  value="<?php echo $paypal_reference_title_box; ?>" name="paypal_reference_title_box" id="paypal_reference_title_box" class="regular-text code" type="text" size="45" />
                                              <span class="description"><?php printf(__('Enter a title for the Reference text box (i.e. Your emeil). The visitors will see this text', 'wpdev-booking'),'<b>','</b>');?></span>
                                          </td>
                                        </tr>

                                        <tr valign="top">
                                          <th scope="row">
                                            <label for="paypal_return_url" ><?php _e('Return URL from PayPal', 'wpdev-booking'); ?>:</label>
                                          </th>
                                          <td>
                                              <input value="<?php echo $paypal_return_url; ?>" name="paypal_return_url" id="paypal_return_url" class="regular-text code" type="text" size="45" />
                                              <span class="description"><?php printf(__('Enter a return URL (could be a Thank You page). PayPal will redirect visitors to this page after Payment', 'wpdev-booking'),'<b>','</b>');?></span>
                                          </td>
                                        </tr>


                                        <tr valign="top">
                                          <th scope="row">
                                            <label for="paypal_button_type" ><?php _e('Button types', 'wpdev-booking'); ?>:</label>
                                          </th>
                                          <td>
                                                <div style="width:150px;margin:auto;float:left;margin:5px;text-align:center;">
                                                        <img src="https://www.paypal.com/en_US/i/btn/btn_paynowCC_LG.gif" /><br/>
                                                        <input <?php if ($paypal_button_type == 'https://www.paypal.com/en_US/i/btn/btn_paynowCC_LG.gif') echo ' checked="checked" '; ?> type="radio" name="paypal_button_type" value="https://www.paypal.com/en_US/i/btn/btn_paynowCC_LG.gif" style="margin:10px;" />
                                                </div>
                                                <div style="width:150px;margin:auto;float:left;margin:5px;text-align:center;">
                                                        <img src="https://www.paypal.com/en_US/i/btn/btn_paynow_LG.gif" /><br/>
                                                        <input <?php if ($paypal_button_type == 'https://www.paypal.com/en_US/i/btn/btn_paynow_LG.gif') echo ' checked="checked" '; ?>  type="radio" name="paypal_button_type" value="https://www.paypal.com/en_US/i/btn/btn_paynow_LG.gif" style="margin:10px;" />
                                                </div>
                                                <div style="width:150px;margin:auto;float:left;margin:5px;text-align:center;">
                                                        <img src="https://www.paypal.com/en_US/i/btn/btn_paynow_SM.gif" /><br/>
                                                        <input <?php if ($paypal_button_type == 'https://www.paypal.com/en_US/i/btn/btn_paynow_SM.gif') echo ' checked="checked" '; ?>  type="radio" name="paypal_button_type" value="https://www.paypal.com/en_US/i/btn/btn_paynow_SM.gif" style="margin:10px;" />
                                                </div>
                                               <span class="description"><?php printf(__('Select type of submittal button', 'wpdev-booking'),'<b>','</b>');?></span>
                                          </td>
                                        </tr>

                                    </tbody>
                                </table>


                                <div class="clear" style="height:10px;"></div>
                                <input class="button-primary" style="float:right;" type="submit" value="<?php _e('Save', 'wpdev-booking'); ?>" name="Submit"/>
                                <div class="clear" style="height:10px;"></div>

                            </form>

                       </div> </div> </div>


                        </div>

        <?php
        }

        // Show Settings at the 1-st page
        function show_general_settings(){

            if (isset($_POST['submit_settings_propay'])) {

                     if (isset( $_POST['range_selection_is_active'] ))     $range_selection_is_active = 'On';
                     else                                                  $range_selection_is_active = 'Off';
                     update_option( 'booking_range_selection_is_active' ,  $range_selection_is_active );

                     if (isset( $_POST['range_selection_time_is_active'] ))     $range_selection_time_is_active = 'On';
                     else                                                  $range_selection_time_is_active = 'Off';
                     update_option( 'booking_range_selection_time_is_active' ,  $range_selection_time_is_active );

                     $range_selection_days_count =  $_POST['range_selection_days_count'];
                     update_option( 'booking_range_selection_days_count' , $range_selection_days_count );

                     $range_start_day =  $_POST['range_start_day'];
                     update_option( 'booking_range_start_day' , $range_start_day );

                     $range_selection_start_time =  $_POST['range_selection_start_time'];
                     update_option( 'booking_range_selection_start_time' , $range_selection_start_time );

                     $range_selection_end_time =  $_POST['range_selection_end_time'];
                     update_option( 'booking_range_selection_end_time' , $range_selection_end_time );

                     $booking_time_format = $_POST['booking_time_format'];
                     update_option( 'booking_time_format' , $booking_time_format );

            }
                    $range_selection_is_active = get_option( 'booking_range_selection_is_active');
                    $range_selection_days_count = get_option( 'booking_range_selection_days_count');
                    $range_start_day = get_option( 'booking_range_start_day');
                    $range_selection_time_is_active = get_option( 'booking_range_selection_time_is_active');
                    $range_selection_start_time  = get_option( 'booking_range_selection_start_time');
                    $range_selection_end_time  = get_option( 'booking_range_selection_end_time');
                    $booking_time_format = get_option( 'booking_time_format');
            ?>
                        <div class="clear" style="height:20px;"></div>

                        <div  style="width:99%; ">

                            <div class='meta-box'>
                                <div  class="postbox" > <h3 class='hndle'><span><?php _e('Advanced Settings', 'wpdev-booking'); ?></span></h3>
                                    <div class="inside">
                                            <form  name="post_option" action="" method="post" id="post_option" >
                                                <table class="form-table"><tbody>

                                                        <tr valign="top">
                                                        <th scope="row"><label for="booking_time_format" ><?php _e('Time Format', 'wpdev-booking'); ?>:</label></th>
                                                            <td><input id="booking_time_format" class="regular-text code" type="text" size="45" value="<?php echo $booking_time_format; ?>" name="booking_time_format"/>
                                                                <span class="description"><?php printf(__('Type your time format for showing in emeils and booking table. %sDocumentation on time formatting.%s', 'wpdev-booking'),'<br/><a href="http://php.net/manual/en/function.date.php" target="_blank">','</a>');?></span>
                                                            </td>
                                                        </tr>


                                                        <tr valign="top">
                                                            <th scope="row">
                                                                <label for="range_selection_is_active" ><?php _e('Range selection', 'wpdev-booking'); ?>:</label>
                                                            </th>
                                                            <td>
                                                                <input <?php if ($range_selection_is_active == 'On') echo "checked";/**/ ?>  value="<?php echo $range_selection_is_active; ?>" name="range_selection_is_active" id="range_selection_is_active" type="checkbox" />
                                                                <span class="description"><?php _e(' Tick this checkbox if you want to use range selection in calendar. For example select week or only 5 days for booking.', 'wpdev-booking');?></span>
                                                            </td>
                                                        </tr>

                                                        <tr valign="top">
                                                        <th scope="row"><label for="range_selection_days_count" ><?php _e('Count of days', 'wpdev-booking'); ?>:</label><br><?php printf(__('in %srange to select%s', 'wpdev-booking'),'<span style="color:#888;font-weight:bold;">','</span>'); ?></th>
                                                            <td><input value="<?php echo $range_selection_days_count; ?>" name="range_selection_days_count" id="range_selection_days_count" class="regular-text code" type="text" size="45"  />
                                                                <span class="description"><?php printf(__('Type your %snumber of days for range selection%s', 'wpdev-booking'),'<b>','</b>');?></span>
                                                            </td>
                                                        </tr>

                                                        <tr valign="top">
                                                            <th scope="row"><label for="range_start_day" ><?php _e('Start day of range', 'wpdev-booking'); ?>:</label></th>
                                                            <td>
                                                                <select id="range_start_day" name="range_start_day" style="width:150px;">
                                                                    <option <?php if($range_start_day == '-1') echo "selected"; ?> value="-1"><?php _e('Any day of week', 'wpdev-booking'); ?></option>
                                                                    <option <?php if($range_start_day == '0') echo "selected"; ?> value="0"><?php _e('Sunday', 'wpdev-booking'); ?></option>
                                                                    <option <?php if($range_start_day == '1') echo "selected"; ?> value="1"><?php _e('Monday', 'wpdev-booking'); ?></option>
                                                                    <option <?php if($range_start_day == '2') echo "selected"; ?> value="2"><?php _e('Thuesday', 'wpdev-booking'); ?></option>
                                                                    <option <?php if($range_start_day == '3') echo "selected"; ?> value="3"><?php _e('Wednesday', 'wpdev-booking'); ?></option>
                                                                    <option <?php if($range_start_day == '4') echo "selected"; ?> value="4"><?php _e('Thursday', 'wpdev-booking'); ?></option>
                                                                    <option <?php if($range_start_day == '5') echo "selected"; ?> value="5"><?php _e('Friday', 'wpdev-booking'); ?></option>
                                                                    <option <?php if($range_start_day == '6') echo "selected"; ?> value="6"><?php _e('Saturday', 'wpdev-booking'); ?></option>
                                                                </select>
                                                                <span class="description"><?php _e('Select your start day of range selection at week', 'wpdev-booking');?></span>
                                                            </td>
                                                        </tr>


                                                        <tr valign="top">
                                                            <th scope="row">
                                                                <label for="range_selection_time_is_active" ><?php _e('Use time', 'wpdev-booking'); ?>:</label>
                                                            </th>
                                                            <td>
                                                                <input <?php if ($range_selection_time_is_active == 'On') echo "checked";/**/ ?>  value="<?php echo $range_selection_time_is_active; ?>" name="range_selection_time_is_active" id="range_selection_time_is_active" type="checkbox" />
                                                                <span class="description"><?php _e(' Tick this checkbox if you want to use for booking part of the day (not full day) at start and end day of range selection. Its will overwrite starttime and endtime from from customization.', 'wpdev-booking');?></span>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                        <th scope="row"><label for="range_selection_start_time" ><?php _e('Start time', 'wpdev-booking'); ?>:</label><br><?php printf(__('%sstart booking time%s', 'wpdev-booking'),'<span style="color:#888;font-weight:bold;">','</span>'); ?></th>
                                                            <td><input value="<?php echo $range_selection_start_time; ?>" name="range_selection_start_time" id="range_selection_start_time" class="wpdev-validates-as-time" type="text" size="5"  />
                                                                <span class="description"><?php printf(__('Type your %sstart%s time of booking for range selection', 'wpdev-booking'),'<b>','</b>');?></span>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                        <th scope="row"><label for="range_selection_end_time" ><?php _e('End time', 'wpdev-booking'); ?>:</label><br><?php printf(__('%send booking time%s', 'wpdev-booking'),'<span style="color:#888;font-weight:bold;">','</span>'); ?></th>
                                                        <td><input value="<?php echo $range_selection_end_time; ?>" name="range_selection_end_time" id="range_selection_end_time" class="wpdev-validates-as-time" type="text" size="5"   />
                                                                <span class="description"><?php printf(__('Type your %send%s time of booking for range selection', 'wpdev-booking'),'<b>','</b>');?></span>
                                                            </td>
                                                        </tr>

                                                </tbody></table>

                                                <input class="button-primary" style="float:right;" type="submit" value="<?php _e('Save Changes', 'wpdev-booking'); ?>" name="submit_settings_propay"/>
                                                <div class="clear" style="height:10px;"></div>
                                            </form>
                                    </div>
                                </div>
                             </div>

                        </div>


            <?php
        }

     //   A C T I V A T I O N   A N D   D E A C T I V A T I O N    O F   T H I S   P L U G I N  ///////////////////////////////////////////////////

            // Activate
            function pro_activate() {
                global $wpdb;
                add_option( 'booking_paypal_emeil', get_option('admin_email') );
                add_option( 'booking_paypal_curency', 'USD' );
                add_option( 'booking_paypal_subject', sprintf(__('Payment for booking of the %s for days: %s' , 'wpdev-booking'),'[bookingname]','[dates]'));
                add_option( 'booking_paypal_is_active','On' );
                add_option( 'booking_paypal_is_reference_box', 'Off' );           // checkbox
                add_option( 'booking_paypal_reference_title_box', __('Enter your phone' , 'wpdev-booking'));
                add_option( 'booking_paypal_return_url', get_option('siteurl') );
                add_option( 'booking_paypal_button_type', 'https://www.paypal.com/en_US/i/btn/btn_paynowCC_LG.gif' );  // radio
                add_option( 'booking_paypal_price_period' , 'day' );

                add_option( 'booking_range_selection_is_active', 'Off');
                add_option( 'booking_range_selection_days_count','3');
                add_option( 'booking_range_start_day' , '-1' );
                add_option( 'booking_range_selection_time_is_active', 'Off');
                add_option( 'booking_range_selection_start_time','12:00');
                add_option( 'booking_range_selection_end_time','14:00');

                add_option( 'booking_time_format', 'H:i');

                if  ($this->is_field_in_table_exists('bookingtypes','cost') == 0){
                    $simple_sql = "ALTER TABLE ".$wpdb->prefix ."bookingtypes ADD cost VARCHAR(100) NOT NULL DEFAULT '0'";
                    $wpdb->query($simple_sql);
                    $wpdb->query( "UPDATE ".$wpdb->prefix ."bookingtypes SET cost = '25'");
                }

            }

            //Decativate
            function pro_deactivate(){

                delete_option( 'booking_paypal_emeil' );
                delete_option( 'booking_paypal_curency' );
                delete_option( 'booking_paypal_subject' );
                delete_option( 'booking_paypal_is_active' );
                delete_option( 'booking_paypal_is_reference_box' );           // checkbox
                delete_option( 'booking_paypal_reference_title_box' );
                delete_option( 'booking_paypal_return_url' );
                delete_option( 'booking_paypal_button_type' );  // radio
                delete_option( 'booking_paypal_price_period' );

                delete_option( 'booking_range_selection_is_active');
                delete_option( 'booking_range_selection_days_count');
                delete_option( 'booking_range_start_day'   );
                delete_option( 'booking_range_selection_time_is_active');
                delete_option( 'booking_range_selection_start_time');
                delete_option( 'booking_range_selection_end_time');

                delete_option( 'booking_time_format');
            }


    }
}
?>
