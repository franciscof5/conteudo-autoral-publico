<?php
/*
This is COMMERSIAL SCRIPT
We are do not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
If you want to have customization, please contact by email - info@wpdevelop.com
*/

if (!class_exists('wpdev_bk_time')) {
    class wpdev_bk_time {
        // Constructor
        function wpdev_bk_time(){

            add_action('wpdev_bk_js_define_variables', array(&$this, 'js_define_variables') );      // Write JS variables
            add_action('wpdev_bk_js_write_files', array(&$this, 'js_write_files') );                // Write JS files

           // add_action('wpdev_bk_general_settings_end', array(&$this, 'show_general_settings'));    // Write General Settings
        }


    //   S U P P O R T     F U N C T I O N S    //////////////////////////////////////////////////////////////////////////////////////////////////



    //   C L I E N T     S I D E    //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // Define JavaScript variables
        function js_define_variables(){
            ?>
                    <script  type="text/javascript">
                        var message_starttime_error = '<?php _e('Start Time is invalid, probably by requesting time(s) already booked, or already in the past!', 'wpdev-booking'); ?>';
                        var message_endtime_error   =   '<?php _e('End Time is invalid, probably by requesting time(s) already booked, or already in the past, or less then start time if only 1 day selected.!', 'wpdev-booking'); ?>';
                    </script>
            <?php
        }

        // Write JS files
        function js_write_files(){
             ?> <script type="text/javascript" src="<?php echo WPDEV_BK_PLUGIN_URL; ?>/include/js/wpdev.bk.time.js"></script>  <?php
        }


    //   A D M I N     S I D E    //////////////////////////////////////////////////////////////////////////////////////////////////////////////



    //   A C T I V A T I O N   A N D   D E A C T I V A T I O N    O F   T H I S   P L U G I N  ///////////////////////////////////////////////////

            // Activate
            function pro_activate() {
                global $wpdb;
                /*
                if  ($this->is_field_in_table_exists('bookingtypes','cost') == 0){
                    $simple_sql = "ALTER TABLE ".$wpdb->prefix ."bookingtypes ADD cost VARCHAR(100) NOT NULL DEFAULT '0'";
                    $wpdb->query($simple_sql);
                    $wpdb->query( "UPDATE ".$wpdb->prefix ."bookingtypes SET cost = '25'");
                }/**/

            }

            //Decativate
            function pro_deactivate(){

 
            }

    }
}