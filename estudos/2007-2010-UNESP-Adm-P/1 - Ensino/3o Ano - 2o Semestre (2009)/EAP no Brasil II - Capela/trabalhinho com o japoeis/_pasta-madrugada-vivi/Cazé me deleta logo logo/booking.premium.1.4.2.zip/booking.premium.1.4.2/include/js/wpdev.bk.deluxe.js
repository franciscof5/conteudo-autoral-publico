// Highlighting range days at calendar
var td_mouse_over = '';

function hoverDayPro(value, date, bk_type) {

    if (date == null) return;

    var i=0 ; var j=0;
    var td_class;

    if (is_select_range == 1) {
        if ( date == null) { return; }

        jWPDev('.datepick-days-cell-over').removeClass('datepick-days-cell-over');                          // clear all selections
        var td_overs = new Array();
        
        //window.status = date.getDay();
        if (range_start_day != -1) {
            if (date.getDay() !=  range_start_day) {
                date.setDate(date.getDate() -  ( date.getDay() -  range_start_day )  );
            }
        }
        for( i=0; i < days_select_count ; i++) {  
            td_class =  (date.getMonth()+1) + '-' + date.getDate() + '-' + date.getFullYear();
            
            if ( ( jWPDev('#calendar_booking'+bk_type+' .cal4date-' + td_class).hasClass('date_user_unavailable') ) || ( jWPDev('#calendar_booking'+bk_type+' .cal4date-' + td_class).hasClass('datepick-unselectable') )){ // If we find some unselect option so then make no selection at all in this range
                             document.body.style.cursor = 'default';  return; 
            }
            //Check if in selection range are reserved days, if so then do not make selection
            if(typeof(date_approved[ bk_type ]) !== 'undefined')
                if(typeof(date_approved[ bk_type ][ td_class ]) !== 'undefined') { //alert(date_approved[ bk_type ][ td_class ][0][5]);
                      for ( j=0; j < date_approved[ bk_type ][ td_class ].length ; j++) {
                            if ( ( date_approved[ bk_type ][ td_class ][j][3] == 0) &&  ( date_approved[ bk_type ][ td_class ][j][4] == 0) )  { document.body.style.cursor = 'default';  return; }
                            if ( ( (date_approved[ bk_type ][ td_class ][j][5] * 1) == 2 ) && (i!=0)) { document.body.style.cursor = 'default';  return; }
                      }
                }
            if(typeof( date2approve[ bk_type ]) !== 'undefined')
                if(typeof( date2approve[ bk_type ][ td_class ]) !== 'undefined') {                   
                      for ( j=0; j < date2approve[ bk_type ][ td_class ].length ; j++) {
                            if ( ( date2approve[ bk_type ][ td_class ][j][3] == 0) &&  ( date2approve[ bk_type ][ td_class ][j][4] == 0) )  { document.body.style.cursor = 'default';  return; }
                            if ( ( (date2approve[ bk_type ][ td_class ][j][5] * 1) == 2 ) && (i!=0)) { document.body.style.cursor = 'default';  return; }
                      }
                }

            td_overs[td_overs.length] = '#calendar_booking'+bk_type+ ' .cal4date-' + td_class;              // add to array for later make selection by class
            date.setDate(date.getDate() + 1);                                                               // Add 1 day to current day
        }
        for ( i=0; i < td_overs.length ; i++) {                                                             // add class to all elements
            var td_element = jWPDev( td_overs[i] );
            td_element.addClass('datepick-days-cell-over');
        }
        
        return ;
    }
   

   

}

// Make range select
function selectDayPro(all_dates,   bk_type){

     if(typeof( prepare_tooltip ) == 'function') {
                    setTimeout("prepare_tooltip("+bk_type+");",1000);
     }

     if (is_select_range == 1) { is_select_range = 0;

        var inst = jWPDev.datepick._getInst(document.getElementById('calendar_booking'+bk_type));

        inst.dates = [];                                        // Emty dates in datepicker
        var all_dates_array;
        var date_array;
        var date;
        var date_to_ins;

        if ( all_dates.indexOf(',') == -1 ){                    // Get array of dates
            all_dates_array = [all_dates]
        } else {
            all_dates_array = all_dates.split(",");
        }

        var original_array = [];
        var isMakeSelection = false;

                // Gathering original (already selected dates) date array
                for( var j=0; j < all_dates_array.length ; j++) {                           //loop array of dates
                    all_dates_array[j] = all_dates_array[j].replace(/(^\s+)|(\s+$)/g, "");  // trim white spaces in date string

                    date_array = all_dates_array[j].split(".");                             // get single date array

                    date=new Date();
                    date.setFullYear( date_array[2],  date_array[1]-1,  date_array[0] );    // get date

                    if ( (date.getFullYear() == inst.cursorDate.getFullYear()) && (date.getMonth() == inst.cursorDate.getMonth()) && (date.getDate() == inst.cursorDate.getDate()) )  {
                        isMakeSelection = true;
                                if (range_start_day != -1) {
                                    if (inst.cursorDate.getDay() !=  range_start_day) {
                                        inst.cursorDate.setDate(inst.cursorDate.getDate() -  ( inst.cursorDate.getDay() -  range_start_day )  );
                                    }
                                }
                    }
                    //original_array.push( jWPDev.datepick._restrictMinMax(inst, jWPDev.datepick._determineDate(inst, date, null))  ); //add date
                }

        var isEmptySelection = false;
        if (isMakeSelection) {
                    original_array.push( jWPDev.datepick._restrictMinMax(inst, jWPDev.datepick._determineDate(inst, inst.cursorDate , null))  ); //add date

                    var dates_array = [];
                    var date_start_range = inst.cursorDate;
                    var range_array = [];
                    var td;
                    // Add dates to the range array
                    for( var i=1; i < days_select_count ; i++) {

                        dates_array[i] = new Date();
                        // dates_array[i].setDate( (date_start_range.getDate() + i) );

                        dates_array[i].setFullYear(date_start_range.getFullYear(),(date_start_range.getMonth()), (date_start_range.getDate() + i) );

                        td =  '#calendar_booking'+bk_type+' .cal4date-' + (dates_array[i].getMonth()+1) + '-'  +  dates_array[i].getDate() + '-' + dates_array[i].getFullYear();
                         if (jWPDev(td).hasClass('datepick-unselectable') ){ // If we find some unselect option so then make no selection at all in this range
                             isEmptySelection = true;
                        }

                        date_to_ins =  jWPDev.datepick._restrictMinMax(inst, jWPDev.datepick._determineDate(inst, dates_array[i], null));

                        range_array.push( date_to_ins );
                    }

                    // check if some dates are the same in the arrays so the remove them from both
                    for( i=0; i < range_array.length ; i++) {
                        for( j=0; j < original_array.length ; j++) {       //loop array of dates

                        if ( (original_array[j] != -1) && (range_array[i] != -1) )
                            if ( (range_array[i].getFullYear() == original_array[j].getFullYear()) && (range_array[i].getMonth() == original_array[j].getMonth()) && (range_array[i].getDate() == original_array[j].getDate()) )  {
                                range_array[i] = -1;
                                original_array[j] = -1;
                            }
                        }
                    }

                    // Add to the dates array
                    for( j=0; j < original_array.length ; j++) {       //loop array of dates
                            if (original_array[j] != -1) inst.dates.push(original_array[j]);
                    }
                    for( i=0; i < range_array.length ; i++) {
                            if (range_array[i] != -1) inst.dates.push(range_array[i]);
                    }
        }
        if (isEmptySelection) inst.dates=[];

        //jWPDev.datepick._setDate(inst, dates_array);
        jWPDev.datepick._updateInput('#calendar_booking'+bk_type);
        jWPDev.datepick._notifyChange(inst);
        jWPDev.datepick._adjustInstDate(inst);
        jWPDev.datepick._showDate(inst);
        //jWPDev.datepick._updateDatepick(inst);

         is_select_range =1;
     }

 }

