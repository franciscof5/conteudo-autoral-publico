jWPDev(document).ready( function(){
   jWPDev('.wpdev-validates-as-time').attr('alt','time');
   jWPDev('.wpdev-validates-as-time').setMask();
});

function write_js_validation(element, inp_value, bk_type) {
        function IsValidTime(timeStr) {
                // Checks if time is in HH:MM AM/PM format.
                // The seconds and AM/PM are optional.

                var timePat = /^(\d{1,2}):(\d{2})(\s?(AM|am|PM|pm))?$/;

                var matchArray = timeStr.match(timePat);
                if (matchArray == null) {
                    return false; //("<?php _e('Time is not in a valid format. Use this format HH:MM or HH:MM AM/PM'); ?>");
                }
                var hour = matchArray[1];
                var minute = matchArray[2];
                var ampm = matchArray[4];

                if (ampm=="") { ampm = null }

                if (hour < 0  || hour > 23) {
                    return  false; //("<?php _e('Hour must be between 1 and 12. (or 0 and 23 for military time)'); ?>");
                }
                if  (hour > 12 && ampm != null) {
                    return  false; //("<?php _e('You can not specify AM or PM for military time.'); ?>");
                }
                if (minute<0 || minute > 59) {
                    return  false; //("<?php _e('Minute must be between 0 and 59.'); ?>");
                }
                return true;
            }


        // Validation Check --- Time correct filling field
        if ( ( element.className.indexOf('wpdev-validates-as-time') !== -1 ) ||  (element.name.indexOf('starttime') !== -1 ) || (element.name.indexOf('endtime') !== -1 ) )  {
            //var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            var valid_time = true;
            
            var my_message = message_time_error;  // Check time for correct fill
            if (inp_value !== '' )  valid_time = IsValidTime(inp_value);

            if( valid_time === true ) // check start time for enterence into diapason
                   if ( element.name.indexOf('starttime') !== -1 ){
                       if(typeof( checkTimeInside ) == 'function') { valid_time = checkTimeInside(element.value, true, bk_type) ; }
                       if (element.value == '') valid_time = false;
                       if( valid_time !== true ) my_message = message_starttime_error;
                   }

            if( valid_time === true ) // check end time for enterence into diapason
                   if ( element.name.indexOf('endtime') !== -1 ){
                       if(typeof( checkTimeInside ) == 'function') { valid_time = checkTimeInside(element.value, false, bk_type) ; }
                       if (element.value == '') valid_time = false;
                       if( valid_time !== true ) my_message = message_endtime_error;
                   }


            if( valid_time !== true ) {
                jWPDev("[name='"+ element.name +"']")
                        .css( {'border' : '1px solid red'} )
                        .fadeOut( 350 )
                        .fadeIn( 500 )
                        .animate( {opacity: 1}, 4000 )
                        .animate({border : '1px solid #DFDFDF'},100)
                ;  // mark red border
                jWPDev("[name='"+ element.name +"']")
                        .after('<div class="wpdev-help-message">'+ my_message +'</div>'); // Show message
                jWPDev(".wpdev-help-message")
                        .css( {'color' : 'red'} )
                        .animate( {opacity: 1}, 10000 )
                        .fadeOut( 2000 );   // hide message
                element.focus();    // make focus to elemnt
                return true;
           }
        }



        return false;
}
