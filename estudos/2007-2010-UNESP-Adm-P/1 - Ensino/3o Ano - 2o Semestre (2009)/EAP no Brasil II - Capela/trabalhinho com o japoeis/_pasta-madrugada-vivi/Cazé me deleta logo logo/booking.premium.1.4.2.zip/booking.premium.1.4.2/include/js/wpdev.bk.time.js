function isDayFullByTime(bk_type, td_class ) {

   var times_array = [];

   // Get dates and time from aproved dates
   if(typeof(date_approved[ bk_type ]) !== 'undefined')
   if(typeof(date_approved[ bk_type ][ td_class ]) !== 'undefined') {
     if( ( date_approved[ bk_type ][ td_class ][0][3] != 0) ||  ( date_approved[ bk_type ][ td_class ][0][4] != 0) ) {
         for ( i=0; i< date_approved[ bk_type ][ td_class ].length; i++){
            h = date_approved[ bk_type ][ td_class ][i][3]; if (h < 10) h = '0' + h;if (h == 0) h = '00';
            m = date_approved[ bk_type ][ td_class ][i][4]; if (m < 10) m = '0' + m;if (m == 0) m = '00';
            s = date_approved[ bk_type ][ td_class ][i][5]; if (s == 2) s = '02';
            times_array[ times_array.length ] = [h,m,s];
         }
     }
   }

   // Get dates and time from pending dates
   if(typeof( date2approve[ bk_type ]) !== 'undefined')
   if(typeof( date2approve[ bk_type ][ td_class ]) !== 'undefined')
     if( ( date2approve[ bk_type ][ td_class ][0][3] != 0) ||  ( date2approve[ bk_type ][ td_class ][0][4] != 0) ) //check for time here
       {  for ( i=0; i< date2approve[ bk_type ][ td_class ].length; i++){
            h = date2approve[ bk_type ][ td_class ][i][3]; if (h < 10) h = '0' + h;if (h == 0) h = '00';
            m = date2approve[ bk_type ][ td_class ][i][4]; if (m < 10) m = '0' + m;if (m == 0) m = '00';
            s = date2approve[ bk_type ][ td_class ][i][5]; if (s == 2) s = '02';
            times_array[ times_array.length ] = [h,m,s];
          }
       }

    times_array.sort();

    for ( var i=0; i< times_array.length; i++){  // s = 2 - end time,   s = 1 - start time
       s = parseInt( times_array[i][2] );

       if  (i == 0) 
            if  (s !== 2)  { return false; } // Its not start at the start of day

       if ( i > 0 ) {

            if ( s == 1 )
                if  ( !( ( times_array[i-1][0] == times_array[i][0] ) &&  ( times_array[i-1][1] == times_array[i][1] ) ) ) {
                        return false; // previos time is not equal to current so we have some free interval
                }

       }

       if (i == ( times_array.length-1)) 
               if (s !== 1)   { return false; } // Its not end  at the end of day

    }
    return true;
}




function hoverDayTime(value, date, bk_type) {

    if (date == null) return;

    var i=0 ; var h ='' ; var m ='' ; var s='';
    var td_class;


   // Gathering information hint for tooltips ////////////////////////////////
   var tooltip_time = '';
   var times_array = [];
   td_class =  (date.getMonth()+1) + '-' + date.getDate() + '-' + date.getFullYear();

   // Get dates and time from aproved dates
   if(typeof(date_approved[ bk_type ]) !== 'undefined')
   if(typeof(date_approved[ bk_type ][ td_class ]) !== 'undefined') {
     if( ( date_approved[ bk_type ][ td_class ][0][3] != 0) ||  ( date_approved[ bk_type ][ td_class ][0][4] != 0) ) {
         for ( i=0; i< date_approved[ bk_type ][ td_class ].length; i++){
            h = date_approved[ bk_type ][ td_class ][i][3]; if (h < 10) h = '0' + h;if (h == 0) h = '00';
            m = date_approved[ bk_type ][ td_class ][i][4]; if (m < 10) m = '0' + m;if (m == 0) m = '00';
            s = date_approved[ bk_type ][ td_class ][i][5]; if (s == 2) s = '02';
            times_array[ times_array.length ] = [h,m,s];
         }
     }
   }

   // Get dates and time from pending dates
   if(typeof( date2approve[ bk_type ]) !== 'undefined')
   if(typeof( date2approve[ bk_type ][ td_class ]) !== 'undefined')
     if( ( date2approve[ bk_type ][ td_class ][0][3] != 0) ||  ( date2approve[ bk_type ][ td_class ][0][4] != 0) ) //check for time here
       {  for ( i=0; i< date2approve[ bk_type ][ td_class ].length; i++){
            h = date2approve[ bk_type ][ td_class ][i][3]; if (h < 10) h = '0' + h;if (h == 0) h = '00';
            m = date2approve[ bk_type ][ td_class ][i][4]; if (m < 10) m = '0' + m;if (m == 0) m = '00';
            s = date2approve[ bk_type ][ td_class ][i][5]; if (s == 2) s = '02';
            times_array[ times_array.length ] = [h,m,s];
          }
       }

    times_array.sort();
// if (times_array.length>0) alert(times_array);
    for ( i=0; i< times_array.length; i++){  // s = 2 - end time,   s = 1 - start time
       s = parseInt( times_array[i][2] );
       if (s == 2) { if (tooltip_time == '') tooltip_time = '&nbsp;&nbsp;&nbsp;&nbsp;...&nbsp;&nbsp;&nbsp; - ';  }      // End time and before was no dates so its start from start of date
       tooltip_time += times_array[i][0] + ':' + times_array[i][1];
       if (s == 1) { tooltip_time += ' - '; if (i == ( times_array.length-1)) tooltip_time += ' &nbsp;&nbsp;&nbsp;&nbsp;... ';  }
       if (s == 2) { tooltip_time += '<br/>'; } /**/
    }
    jWPDev( '#demotip'+bk_type ).html( tooltip_time );
    ////////////////////////////////////////////////////////////////////////

}


function isTimeTodayGone(myTime, sort_date_array){

    if (( sort_date_array[0][0] == wpdev_bk_today[0] ) && ( sort_date_array[0][1] == wpdev_bk_today[1]  ) && ( sort_date_array[0][2] == wpdev_bk_today[2]  )) {
        var mytime_value = myTime.split(":");
        mytime_value = mytime_value[0]*60 + parseInt(mytime_value[1]);

        var current_time_value = wpdev_bk_today[3]*60 + parseInt(wpdev_bk_today[4]);

        if ( current_time_value  > mytime_value ) return true;

    }

    return false;
}


var start_time_checking_index;
// Function check start and end time at selected days
function checkTimeInside( mytime, is_start_time, bk_type ) {



    var my_dates_str = document.getElementById('date_booking'+ bk_type ).value;                 // GET DATES From TEXTAREA
    var date_array = my_dates_str.split(", ");
    var temp_elemnt;  var td_class; var sort_date_array = []; var work_date_array = []; var times_array = []; var is_check_for_time;

    for (var i=0; i< date_array.length; i++) {  // Get SORTED selected days array
        temp_elemnt = date_array[i].split(".");
        sort_date_array[i] = [ temp_elemnt[2], temp_elemnt[1] + '', temp_elemnt[0] + '' ]; // [2009,7,1],...
    }
    sort_date_array.sort();                                                                   // SORT    D a t e s
    for (i=0; i< sort_date_array.length; i++) {                                  // trnasform to integers
        sort_date_array[i] = [ parseInt(sort_date_array[i][0]*1), parseInt(sort_date_array[i][1]*1), parseInt(sort_date_array[i][2]*1) ]; // [2009,7,1],...
    }
    
    if (is_start_time) {
        if ( isTimeTodayGone(mytime, sort_date_array) )  return false;
    }
    //  CHECK FOR BOOKING INSIDE OF     S E L E C T E D    DAY RANGE AND FOR TOTALLY BOOKED DAYS AT THE START AND END OF RANGE
    work_date_array =  sort_date_array;
    for (var j=0; j< work_date_array.length; j++) {
        td_class =  work_date_array[j][1] + '-' + work_date_array[j][2] + '-' + work_date_array[j][0];

        if ( (j==0) || (j == (work_date_array.length-1)) ) is_check_for_time = true;         // Check for time only start and end time
        else                                               is_check_for_time = false;

        // Get dates and time from pending dates
        if(typeof( date2approve[ bk_type ]) !== 'undefined') {
          if ( (typeof( date2approve[ bk_type ][ td_class ]) !== 'undefined') ) {
             if (! is_check_for_time) { return false; } // its mean that this date is booked inside of range selected dates
             if( ( date2approve[ bk_type ][ td_class ][0][3] != 0) ||  ( date2approve[ bk_type ][ td_class ][0][4] != 0) ) {
                 // Evrything good - some time is booked check later
             } else {  return false; } // its mean that this date tottally booked
          }
        }

        // Get dates and time from pending dates
        if(typeof( date_approved[ bk_type ]) !== 'undefined') {
          if ( (typeof( date_approved[ bk_type ][ td_class ]) !== 'undefined') ) {
             if (! is_check_for_time) { return false; } // its mean that this date is booked inside of range selected dates
             if( ( date_approved[ bk_type ][ td_class ][0][3] != 0) ||  ( date_approved[ bk_type ][ td_class ][0][4] != 0) ) {
                 // Evrything good - some time is booked check later
             } else {  return false; } // its mean that this date tottally booked
          }
        }
    }  ///////////////////////////////////////////////////////////////////////////////////////////////////////


     // Check    START   OR    END   time for time no in correct fee range
     if (is_start_time ) work_date_array =  sort_date_array[0] ;
     else                work_date_array =  sort_date_array[sort_date_array.length-1] ;

     td_class =  work_date_array[1] + '-' + work_date_array[2] + '-' + work_date_array[0];

        // Get dates and time from pending dates
        if(typeof( date2approve[ bk_type ]) !== 'undefined')
          if(typeof( date2approve[ bk_type ][ td_class ]) !== 'undefined')
              for ( i=0; i< date2approve[ bk_type ][ td_class ].length; i++){
                h = date2approve[ bk_type ][ td_class ][i][3]; if (h < 10) h = '0' + h;if (h == 0) h = '00';
                m = date2approve[ bk_type ][ td_class ][i][4]; if (m < 10) m = '0' + m;if (m == 0) m = '00';
                s = date2approve[ bk_type ][ td_class ][i][5];
                times_array[ times_array.length ] = [h,m,s];
              }

        // Get dates and time from pending dates
        if(typeof( date_approved[ bk_type ]) !== 'undefined')
          if(typeof( date_approved[ bk_type ][ td_class ]) !== 'undefined')
              for ( i=0; i< date_approved[ bk_type ][ td_class ].length; i++){
                h = date_approved[ bk_type ][ td_class ][i][3]; if (h < 10) h = '0' + h;if (h == 0) h = '00';
                m = date_approved[ bk_type ][ td_class ][i][4]; if (m < 10) m = '0' + m;if (m == 0) m = '00';
                s = date_approved[ bk_type ][ td_class ][i][5];
                times_array[ times_array.length ] = [h,m,s];
              }


        times_array.sort();                     // SORT TIMES

        var times_in_day = [];                  // array with all times
        var times_in_day_interval_marks = [];   // array with time interval marks 1- stsrt time 2 - end time


        for ( i=0; i< times_array.length; i++){  s = times_array[i][2];         // s = 2 - end time,   s = 1 - start time
           // Start close interval
           if ( (s == 2) &&  (i == 0) ) { times_in_day[ times_in_day.length ] = 0; times_in_day_interval_marks[times_in_day_interval_marks.length]=1; }
           // Normal
           times_in_day[ times_in_day.length ] = times_array[i][0] * 60 + parseInt(times_array[i][1]);
           times_in_day_interval_marks[times_in_day_interval_marks.length]=s;
           // End close interval
           if ( (s == 1) &&  (i == (times_array.length-1)) ) { times_in_day[ times_in_day.length ] = (24*60);  times_in_day_interval_marks[times_in_day_interval_marks.length]=2; }
        }

        // Get time from entered time
        var mytime_value = mytime.split(":");
        mytime_value = mytime_value[0]*60 + parseInt(mytime_value[1]);

//alert('My time:'+ mytime_value + '  List of times: '+ times_in_day + '  Saved indexes: ' + start_time_checking_index + ' Days: ' + sort_date_array ) ;

        var start_i = 0;
        if ( (! is_start_time) && (sort_date_array.length == 1) ) { start_i = start_time_checking_index[0]; /*start_i++;*/ }
        i=start_i;

        // Main checking inside a day
        for ( i=start_i; i< times_in_day.length; i++){
            if (is_start_time ) {
                if ( mytime_value > times_in_day[i] ){
                    // Its Ok, lets Loop to next item
                } else if ( mytime_value == times_in_day[i] ) {
                    if (times_in_day_interval_marks[i] == 1 ) { return false;     //start time is begin with some other interval
                    } else {
                        if ( (i+1) <= (times_in_day.length-1) ) {
                            if ( times_in_day[i+1] <= mytime_value ) return false;  //start time  is begin with next elemnt interval
                            else  {                                                 // start time from end of some other
                                if (sort_date_array.length > 1)
                                    if ( (i+1) <= (times_in_day.length-1) ) return false;   // Its mean that we make end booking at some other day then this and we have some booking time at this day after start booking  - its wrong
                                start_time_checking_index = [i, td_class,mytime_value];
                                return true;
                            }
                        }
                        if (sort_date_array.length > 1)
                            if ( (i+1) <= (times_in_day.length-1) ) return false;   // Its mean that we make end booking at some other day then this and we have some booking time at this day after start booking  - its wrong
                        start_time_checking_index = [i, td_class,mytime_value];
                        return true;                                            // start time from end of some other
                    }
                } else  if ( mytime_value < times_in_day[i] ) {
                    if (times_in_day_interval_marks[i] == 2 ){ return false;     // start time inside of some interval
                    } else {
                        if (sort_date_array.length > 1)
                            if ( (i+1) <= (times_in_day.length-1) ) return false;   // Its mean that we make end booking at some other day then this and we have some booking time at this day after start booking  - its wrong
                        start_time_checking_index = [i, td_class,mytime_value];
                        return true;
                    }
                }
            } else {
                if (sort_date_array.length == 1) {
                    if ( ( start_time_checking_index[2] == times_in_day[i] ) && ( times_in_day_interval_marks[i] == 2) ) {    // Good, because start time = end of some other interval and we need to get next interval for current end time.
                    } else if ( times_in_day[i] < mytime_value ) return false;                 // some interval begins before end of curent "end time"
                    else {
                        if (start_time_checking_index[2]>= mytime_value) return false;  // we are select only one day and end time is earlythe starttime its wrong
                        return true;                                                    // if we selected only one day so evrything is fine and end time no inside some other intervals
                    }
                } else {

                    if ( times_in_day[i] < mytime_value ) return false;                 // Some other interval start before we make end time in the booking at the end day selection
                    else return true;


                }

            }
        }

        if (is_start_time )  start_time_checking_index = [i, td_class,mytime_value];
        else {
           if ( (sort_date_array.length == 1) && (start_time_checking_index[2]>= mytime_value) ) return false;  // we are select only one day and end time is earlythe starttime its wrong
        }
        return true;
}
