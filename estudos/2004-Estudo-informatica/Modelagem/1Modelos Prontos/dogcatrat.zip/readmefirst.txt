The files called cataniminfo.txt, doganiminfo.tx and rataniminfo.txt contain the animation ranges for each model....

dog, cat, rat.CFX are the character FX 1.3 files

dog, cat, rat.MS3D are the Milkshape 1.63 files

dog, cat01, rat.JPG are the skins for each model feel free to change em :-)

dog, cat, rat.B3D are the Blitzbasic 3d format models.....

Also the scales aren't right, the dog is big and so is the rat so scale em up/down to suit you!!

OK, hope somebody out there finds em useful!

Psionic